from setuptools import setup

setup(
    
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Joseph Ruiz",
    author_email="ruizdev7@outlook.com",
    url="www.pagina.com",
    packages=["calculos"]

        )

